<link rel="stylesheet" type="text/css" href="static/css/loading.css?<?php echo 5; ?>">
<link rel="stylesheet" type="text/css" href="static/css/body.css?<?php echo 5; ?>">
<style>
    body{
        background:black;
    }
</style>
<div class = "loading">
    <div class = "img-container">
        <img src = "static/assets/scavengerHunt/RdevPixel.webp" class = "sub-img">
        <img src = "static/assets/scavengerHunt/RdevPixel.webp" class = "main-img">
    </div>
    <p>Let's create something amazing together!<br>Paint 1 pixel on this giant canvas for 1 point each. Up to 100 pixels can be placed per user.</p>
    <input type = "button" value = "Start" class = "default-button2 start">
</div>