<?php
define("clientID", "361480912344-4mtt5s2d2ae1h29vr3neh7q7tr42b6gk.apps.googleusercontent.com");
define("clientSecret", "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");
define("redirecturl", "http://localhost/2023RVprom/backend/Login/login.php");
?>