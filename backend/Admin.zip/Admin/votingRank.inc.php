<?php
if (!$isAdmin) exit();
$sql = "SELECT `guestId`,`class`,`studentName`,`tableNo` FROM `guests`";
$result = mysqli_query($conn, $sql);
$guestInfo = [];
while ($row = mysqli_fetch_assoc($result)) {
    $guestInfo[$row["guestId"]] = ["class" => $row["class"], "studentName" => $row["studentName"], "tableNo" => $row["tableNo"]];
}

$sql = "
SELECT s.`guestId1`,s.`guestId2`,s.`category`,`image`,`nomineeDesc`,`voteCount` FROM `guests`
JOIN 
(SELECT `guestId1`,`guestId2`,category,COUNT(*) as voteCount FROM `votes` 
GROUP BY `guestId1`,`category` 
ORDER BY `voteCount` DESC) s ON s.`guestId1` = `guests`.`guestId`
LEFT JOIN `nominees` ON `nominees`.`guestId1` = `guests`.`guestId`";
$result = mysqli_query($conn, $sql);
$data = ['0'=>[],'1'=>[],'2'=>[],'3'=>[],'4'=>[]];
while ($row = mysqli_fetch_assoc($result)) {
    $data[$row["category"]][] = $row;
}
?>