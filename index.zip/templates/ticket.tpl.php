<link rel="stylesheet" href="static/css/ticket.css?<?php echo time(); ?>">
<meta name="pageTitle" content="ticket">

</head>

<body>
    <?php if (!$guestInfo){
        echo "<script>alert('Not Logged in! Please login before continuing');window.location.href = 'index.php'</script>";
        }?>
    <?php require "templates/defaults/nav.tpl.php"?>
    <div class="main">
        <img src="static/assets/ticket/ticket.png" class="ticket">
        <div class="guest-code__container">
            <div id="guest-code"></div>
            <div class="guest-code__name"><?php echo $guestInfo["studentName"]?></div>
            <div class="guest-code__table">Table <?php echo $guestInfo["tableNo"]?></div>
        </div>
    </div>
    <script src="static/qrcode/qrcode.min.js"></script>
    <script src="static/js/ticket.js" defer></script>