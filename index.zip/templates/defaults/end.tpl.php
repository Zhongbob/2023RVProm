	<script src = "static/js/defaults.js?<?php echo time(); ?>"></script>
	<script src = "static/js/nav.js?<?php echo time(); ?>"></script>
</body>
</html>