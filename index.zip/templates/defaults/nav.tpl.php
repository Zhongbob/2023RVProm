    <nav class = "nav" id = "nav" >

        <a href = "index.php" class = "nav__cell"  id = "home">
            <input type = "button" value = "Home" class = "nav__btn">
        </a>
        <a href = "index.php?filename=ticket" class = "nav__cell" id = "ticket">                    
            <input type = "button"  value = "Ticket" class = "nav__btn">
            
        </a>

        <a target = "_blank" href = "https://www.instagram.com/rv_promenade/" class = "nav__cell nav__cell--rdev">
            <div >
                <input alt = "prom instagram page" class = "nav__cell-image nav__cell-image--rdev" type = "image" src = "static/assets/default/logo.png">
            </div>
        </a>

        
        <!-- <img src = "assets/placeholder.png" id = "website_logo"> -->
    </nav>
